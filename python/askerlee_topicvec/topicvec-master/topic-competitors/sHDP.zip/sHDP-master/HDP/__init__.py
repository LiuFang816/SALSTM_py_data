# __all__ = something
import HDP
import HDP.models
import HDP.basic
import HDP.basic.distributions as distributions # shortcut
import HDP.util

import os
EIGEN_INCLUDE_DIR = os.path.join(os.path.dirname(__file__), 'deps/Eigen3')

